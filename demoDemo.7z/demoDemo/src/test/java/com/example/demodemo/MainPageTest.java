package com.example.demodemo;

import com.codeborne.selenide.WebDriverRunner;
import com.codeborne.selenide.Configuration;
import com.codeborne.selenide.Selenide;
import com.codeborne.selenide.logevents.SelenideLogger;
import io.qameta.allure.selenide.AllureSelenide;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.*;

import static com.codeborne.selenide.Condition.*;
import static org.testng.Assert.*;

import static com.codeborne.selenide.Selenide.*;

import java.awt.*;

public class MainPageTest {
    MainPage mainPage = new MainPage();

    public static WebDriver driver;

    @BeforeClass
    public static void setUpAll() {
        //System.setProperty("webdriver.chrome.driver", "E:\\0001999e\\chromedriver_win32 (1)\\chromedriver.exe");
        //driver = new ChromeDriver();
        //Configuration.browserSize = "1280x800";
        //SelenideLogger.addListener("allure", new AllureSelenide());
    }

    @BeforeMethod
    public void setUp() {

    }

    @Test
    public void login() {
        open("https://web.neobank.one/");

        assertEquals(Selenide.title(), "NEOBANK для бізнесу");

        mainPage.numberField.sendKeys("636901699");

        mainPage.numberButton.click();

        WebDriver driver = WebDriverRunner.getWebDriver();
        driver.manage().window().maximize();

        mainPage.seeText.shouldHave(exactText("Відкриття бізнес-рахунку можливе тільки через додаток NEOBANK для бізнесу"));

        Selenide.closeWindow();
    }

}
